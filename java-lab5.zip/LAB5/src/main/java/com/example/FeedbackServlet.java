
package com.example;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class FeedbackServlet extends HttpServlet {

    private String escapeHTML(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        // Get feedback form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String feedbackType = request.getParameter("feedbackType");
        String comments = request.getParameter("comments");

        // Validate input
        if (name == null || name.isBlank()
                || email == null || email.isBlank()
                || comments == null || comments.isBlank()
                || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {

            response.sendError(400, "Please enter valid details.");
            return;
        }

        if (!"Complaint".equals(feedbackType)
                && !"Suggestion".equals(feedbackType)
                && !"Compliment".equals(feedbackType)) {

            response.sendError(400, "Invalid feedback type.");
            return;
        }

        // Get current date and time
        String dateTime = LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")
        );

        // Display submitted feedback
        response.getWriter().println("""
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport"
                      content="width=device-width, initial-scale=1.0">
                <title>Feedback Submitted</title>

                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background: #eff6ff;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        margin: 0;
                        padding: 20px;
                    }

                    .card {
                        background: white;
                        padding: 35px;
                        width: 100%;
                        max-width: 500px;
                        border-radius: 15px;
                        box-shadow: 0 8px 25px #00000015;
                    }

                    h1 {
                        color: #16a34a;
                    }

                    p {
                        color: #334155;
                        line-height: 1.7;
                        overflow-wrap: anywhere;
                    }

                    a {
                        display: inline-block;
                        background: #2563eb;
                        color: white;
                        padding: 12px 20px;
                        border-radius: 7px;
                        text-decoration: none;
                        margin-top: 15px;
                    }
                </style>
            </head>

            <body>
                <div class="card">

                    <h1>Thank You!</h1>

                    <h2>Thank you, %s for your feedback!</h2>

                    <p><b>Email:</b> %s</p>
                    <p><b>Feedback Type:</b> %s</p>
                    <p><b>Comments:</b> %s</p>
                    <p><b>Date and Time:</b> %s</p>

                    <a href="feedback.html">
                        Submit Another Feedback
                    </a>

                </div>
            </body>
            </html>
            """.formatted(
                escapeHTML(name),
                escapeHTML(email),
                escapeHTML(feedbackType),
                escapeHTML(comments),
                escapeHTML(dateTime)
            ));
    }
}
